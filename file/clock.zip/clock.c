#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <time.h>
#define ID_TIMER  1
#define PI 3.141592654
static int CX=320,CY=240;
void Draw_Dial(HDC);//���ƾ�̬�ı���
void Draw_Hand(HDC,int hour, int minute, int secend); //���Ʊ���
HWND _workerw = NULL;
time_t timer;
struct tm *tms;
BOOL CALLBACK EnumWindowsProc(HWND tophandle,LPARAM topparamhandle)
{
    HWND defview = FindWindowEx(tophandle, 0, "SHELLDLL_DefView", NULL);
    if (defview != NULL)
    {
        _workerw = FindWindowEx(0,tophandle, "WorkerW", 0);
    }
    return TRUE;
}

HWND GetWorkerW(){
    int result;
    HWND windowHandle = FindWindow("Progman", NULL);
    SendMessageTimeout(windowHandle, 0x052c, 0 ,0, SMTO_NORMAL, 0x3e8,(PDWORD_PTR)&result);
    EnumWindows(EnumWindowsProc,(LPARAM)NULL);
    ShowWindow(_workerw,SW_HIDE);
    return windowHandle;
} 

LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM) ;
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
          PSTR szCmdLine, int iCmdShow)
{

    static TCHAR szAppName[] = TEXT ("matrix") ;
    HWND      hwnd ;
    MSG      msg ;
    WNDCLASS  wndclass ;
 
    wndclass.style        = CS_HREDRAW | CS_VREDRAW ; // class style
    wndclass.lpfnWndProc    = WndProc ;
    wndclass.cbClsExtra    = 0 ;
    wndclass.cbWndExtra    = 0 ;
    wndclass.hInstance    = hInstance ;
    wndclass.hIcon        = LoadIcon (NULL, IDI_APPLICATION) ;
    wndclass.hCursor    = LoadCursor (NULL, IDC_ARROW) ;
    wndclass.hbrBackground    = (HBRUSH) GetStockObject (BLACK_BRUSH) ;
    wndclass.lpszMenuName    = NULL ;
    wndclass.lpszClassName    = szAppName ;
 
    if(!RegisterClass (&wndclass))
    {
      MessageBox (NULL, TEXT ("�˳������������NT��!"), szAppName, MB_ICONERROR) ;
      return 0;
    }
 
    hwnd = CreateWindow (szAppName, NULL,
              WS_DLGFRAME | WS_THICKFRAME | WS_POPUP, // windows style
              0, 0,
              GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
              NULL, NULL, hInstance,
              NULL) ;
	SetParent(hwnd,GetWorkerW());
    ShowWindow (hwnd, SW_SHOWMAXIMIZED) ; //�����ʾ show windows
    UpdateWindow (hwnd) ;
    ShowCursor(FALSE); //���������
    while (GetMessage (&msg, NULL, 0, 0))
    {
      TranslateMessage (&msg) ;
      DispatchMessage (&msg) ;
    }
    ShowCursor(TRUE); //��ʾ�����
    return msg.wParam ;
}
 
 
LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
   HDC   hdc ;
   //ctn ����ȷ��һ����ʾ���Ƿ� ����ǰ��,����ȴ�������������ȴ��Ĵ���,ctn�ʹ���Ҫ����ǰ��
   static HDC hdcMem,hdcMem2;
   static int cxScreen, cyScreen; //��Ļ�Ŀ��� �߶�.
   static int iFontWidth=10, iFontHeight=15, iColumnCount; //����Ŀ��� �߶�, ����
   
   static HBITMAP hbmp; static BITMAPFILEHEADER *pbmfh;
static HANDLE fp; DWORD dwFZ, dwHZ, dwBR;
   switch (message)
   {
    case WM_CREATE:
		cxScreen = GetSystemMetrics(SM_CXSCREEN) ; //��Ļ����
		cyScreen = GetSystemMetrics(SM_CYSCREEN) ;
		CX=cxScreen>>1;CY=cyScreen>>1;
		SetTimer (hwnd, ID_TIMER, 1000, NULL) ;
		  
		
		fp = CreateFile("bg.bmp", GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
		if (fp != INVALID_HANDLE_VALUE){
			dwFZ = GetFileSize(fp, &dwHZ);
			if (dwHZ) CloseHandle(fp);
			pbmfh =(BITMAPFILEHEADER*)malloc(dwFZ);
			ReadFile(fp, pbmfh, dwFZ, &dwBR, NULL);
			CloseHandle(fp);
		}
					
		hdc = GetDC(hwnd);
		
		hbmp = CreateCompatibleBitmap(hdc, cxScreen, cyScreen);
		hdcMem = CreateCompatibleDC(hdc);
		SelectObject(hdcMem, hbmp);
		hdcMem2 = CreateCompatibleDC(hdc);
		hbmp = CreateDIBitmap(hdc, (BITMAPINFOHEADER*)(pbmfh + 1), CBM_INIT, (BYTE*)pbmfh + pbmfh->bfOffBits, (BITMAPINFO*)(pbmfh + 1), DIB_RGB_COLORS);
		SelectObject(hdcMem2, hbmp);
		SelectObject(hdcMem,GetStockObject(BLACK_BRUSH));
		ReleaseDC(hwnd, hdc);
		//��������
		SetBkMode(hdcMem, TRANSPARENT); //���ñ���ģʽΪ ͸��
		return 0 ;
 
    case WM_TIMER:
      hdc = GetDC(hwnd);
	  PatBlt (hdcMem, 0, 0, cxScreen, cyScreen, BLACKNESS) ; //���ڴ��豸ӳ��ˢ�ɺ�ɫ  
	BitBlt(hdcMem, 0, 0, cxScreen, cyScreen, hdcMem2,0,0,SRCCOPY) ;
	Draw_Dial(hdcMem);
	  timer=time(NULL);tms=localtime(&timer);
	
	  
	  Draw_Hand(hdcMem,tms->tm_hour,tms->tm_min,tms->tm_sec); //�ѱ�����Ƴ���
	  
      BitBlt(hdc, 0, 0, cxScreen, cyScreen, hdcMem, 0, 0, SRCCOPY);
      ReleaseDC(hwnd, hdc);
      return 0;
 
    case WM_RBUTTONDOWN:
      KillTimer (hwnd, ID_TIMER) ;
      return 0;
 
    case WM_RBUTTONUP:
      SetTimer (hwnd, ID_TIMER, 10, NULL) ;
      return 0;
 
    //�����ƺ���
    case WM_KEYDOWN:
    case WM_LBUTTONDOWN:
    case WM_DESTROY:
      KillTimer (hwnd, ID_TIMER) ;
      DeleteObject(hbmp);
      DeleteDC(hdcMem);
      DeleteDC(hdcMem2);
      PostQuitMessage (0) ;
      return 0 ;
    }
    return DefWindowProc (hwnd, message, wParam, lParam) ;
}





void Draw_Dial(HDC hdc)
{

	//���Ʊ߽�
	HPEN wpen,rpen;
	wpen=CreatePen(PS_SOLID,2,0xff00);
	rpen=CreatePen(PS_SOLID,0,0x0000ff);
	SelectObject(hdc,wpen);
	int x,y,i;
	for (i = 0; i < 60;i++)
	{
		x=CX+sin(PI*2*i/60)*290;
		y=CY+cos(PI*2*i/60)*290;
		
		//~ x = 320 + int(145*sin(PI*2*i/60));
		//~ y = 240 + int(145 * cos(PI * 2 * i / 60));

		if (i % 15 == 0)

			Rectangle(hdc,x - 5, y - 5, x + 5, y + 5);

		else if (i % 5 == 0)

			Ellipse(hdc,x-3, y-3,x+3,y+3);

		else

			Ellipse(hdc,x-1, y-1,x+2,y+2);

	}

}

void Draw_Hand(HDC hdc,int hour, int minute, int second)

{

	double h_hour, h_minute, h_second; //��������ֵ

	int x_hour, y_hour, x_minute, y_minute, x_second, y_second; //ĩ��λ��

	//���㻡��ֵ

	h_second = second * 2 * PI / 60;

	h_minute = minute * 2 * PI / 60 + h_second / 60;

	h_hour = hour * 2 * PI / 12 + h_minute / 12;

	//����ĩ��λ��
	int a=280,b=210,c=180;
	x_second = sin(h_second)*a; y_second=cos(h_second)*a;

	x_minute = sin(h_minute)*b; y_minute = cos(h_minute)*b;

	x_hour =sin(h_hour)*c; y_hour = cos(h_hour)*c;

	//��������
	HPEN gpen,ypen,rpen;
	gpen=CreatePen(PS_SOLID,7,0xff00);
	ypen=CreatePen(PS_SOLID,6,0xffff);
	rpen=CreatePen(PS_SOLID,2,0x0000ff);
	SelectObject(hdc,rpen);
	
	MoveToEx(hdc,CX+x_second,CY-y_second,NULL);
	LineTo(hdc,CX-x_second/3,CY+y_second/3);
	//~ line(320 + x_second, 240 - y_second, 320 - x_second / 3, 240 + y_second / 3);

	//���Ʒ���

	SelectObject(hdc,ypen);
	
	//~ line(320 + x_minute, 240 - y_minute, 320 - x_minute / 5, 240 + y_minute/5);
	MoveToEx(hdc,CX+x_minute,CY-y_minute,NULL);
	LineTo(hdc,CX-x_minute/5,CY+y_minute/5);
	

	//����ʱ��

	SelectObject(hdc,gpen);
	//~ line(320 + x_hour, 240 - y_hour, 320 - x_hour / 5, 240 + y_hour/5);
	MoveToEx(hdc,CX+x_hour,CY-y_hour,NULL);
	LineTo(hdc,CX-x_hour/5,CY+y_hour/5);

}


















