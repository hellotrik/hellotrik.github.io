from .sheng import *
from .sheng.interface import numpy as np
from .ya import *
import trik.yu as yu